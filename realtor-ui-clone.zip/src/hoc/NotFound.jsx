import { Link } from "react-router-dom";

import '../App.css'

function NotFound() {
  return (
    <div className="d-flex h-100 w-100 flex-column align-items-center justify-content-center">
      <h1 className="text-lg">404 - Not Found!</h1>
      <Link to="/" className="btn btn-outline-light text-black">&laquo; Go Home</Link>
    </div>
  );
}

export default NotFound;
