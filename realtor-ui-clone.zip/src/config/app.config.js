export const APP_NAME = "Realtor";
