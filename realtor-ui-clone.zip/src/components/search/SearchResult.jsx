import { MapContainer, Marker, Popup, TileLayer } from "react-leaflet";
import L from "leaflet";
import Dot from "../../assets/location-dot-solid.svg";

const iconPoint = new L.Icon({
  iconUrl: Dot,
  iconRetinaUrl: Dot,
  iconAnchor: null,
  popupAnchor: null,
  shadowUrl: null,
  shadowSize: null,
  shadowAnchor: null,
  iconSize: new L.Point(20, 35),
  className: "leaflet-div-icon border-0 bg-transparent",
});

export default function SearchResult() {
  console.log(iconPoint);
  return (
    <main className="container my-5">
      <h4 className="border-bottom py-2">Search Results for {"Ontario"}</h4>
      <div className="row mt-3">
        <div className="col-md-6">
          {Array(10)
            .fill(0)
            .map((v, i) => (
              <div className="card shadow-sm cursor-pointer mb-3" key={i}>
                <div className="card-body row py-0">
                  <div className="col-md-4 px-0">
                    <img
                      src="https://c4.wallpaperflare.com/wallpaper/241/699/670/274-apartment-condo-design-wallpaper-preview.jpg"
                      alt="wallpaper"
                      className="img-fluid h-100 object-cover"
                    />
                  </div>
                  <div className="col-md-8 pe-4 py-2">
                    <div className="card-body p-0">
                      <h4 className="d-flex justify-content-between align-items-center">
                        <span>
                          Property name{" "}
                          <i className="bi-star-fill text-warning fs-6 cursor-pointer"></i>
                        </span>
                        <small className="fs-6">1200/sqft</small>
                      </h4>
                      <h6>$25,000</h6>
                      <section>
                        <span className="bg-dark text-white small px-2 py-1 rounded">
                          For Sale
                        </span>
                        <span className="bg-primary text-white small px-2 py-1 mx-2 rounded">
                          Featured
                        </span>
                      </section>
                      <p className="card-text my-2">
                        This is a wider card with supporting text below as a
                        natural lead-in to additional content. This content is a
                        little bit longer.
                      </p>
                      <div className="d-flex justify-content-between align-items-center">
                        <div className="btn-group">
                          <button
                            type="button"
                            className="btn btn-sm border-0 shadow-none px-0"
                          >
                            3 bed(s)
                          </button>
                          <button
                            type="button"
                            className="btn btn-sm border-0 shadow-none"
                          >
                            1 bath(s)
                          </button>
                        </div>
                        <small className="text-muted">9 mins ago</small>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </div>
        <div className="col-md-6">
          <div className="position-sticky" style={{ top: "2rem" }}>
            <MapContainer
              center={[51.505, -0.09]}
              zoom={13}
              style={{ height: "500px" }}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <Marker position={[51.505, -0.09]} icon={iconPoint}>
                <Popup>
                  A pretty CSS3 popup. <br /> Easily customizable.
                </Popup>
              </Marker>
            </MapContainer>
          </div>
        </div>
      </div>
    </main>
  );
}
