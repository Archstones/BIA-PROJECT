import { MapContainer, Marker, Popup, TileLayer } from "react-leaflet";
import L from "leaflet";
import Dot from "../../assets/location-dot-solid.svg";
import {
  Link,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import Header from "../nav/Header";

const iconPoint = new L.Icon({
  iconUrl: Dot,
  iconRetinaUrl: Dot,
  // iconAnchor: null,
  // popupAnchor: null,
  shadowUrl: null,
  shadowSize: null,
  shadowAnchor: null,
  iconSize: new L.Point(20, 35),
  className: "leaflet-div-icon border-0 bg-transparent",
});

export default function SearchResult() {
  const [search, setSearch] = useSearchParams();
  const [token] = useState(localStorage.getItem("realtor-token"));
  const [results, setResults] = useState([]);
  const [coords, setCoords] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (!search.get("query") && search.get("hold") !== "true") {
      navigate("/home", { replace: true });
      return;
    }
    if (search.get("query")) {
      axios
        .get(`/search/property/${search.get("query")}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        .then((res) => {
          if (res.status === 200) {
            setResults([...res.data]);
            setCoords([
              ...res.data.map((d) => ({
                lat: d.address.latitude,
                lng: d.address.longitude,
                title: d.name,
              })),
            ]);
          }
        })
        .catch(() => {
          alert("Something went wrong");
        });
    }
  }, [search.get("query"), search.get("hold")]);
  return (
    <Header noFooter={true}>
      <main className="container mb-5 bg-white py-5 px-2">
        <div className="border-bottom py-2 d-flex justify-content-between">
          <h4>Search Results for {search.get("query")}</h4>
          <input
            type="text"
            className="form-control w-25"
            placeholder="Search here"
            value={search.get("query")}
            onInput={(ev) => {
              if (ev.target.value === "") {
                setSearch({ query: ev.target.value, hold: true });
              } else {
                setSearch({ query: ev.target.value });
              }
            }}
          />
        </div>
        {results.length === 0 && (
          <div className="row mt-3">
            <h3>No results found for {search.get("query")}</h3>
          </div>
        )}
        {results.length > 0 && (
          <div className="row mt-3">
            <div className="col-md-6">
              {results.map((v, i) => (
                <Link
                  to={`/property/${v._id}`}
                  className="text-decoration-none text-black"
                >
                  <div
                    className="card shadow-sm cursor-pointer mb-3"
                    key={i}
                    style={{ maxHeight: "200px", height: "200px" }}
                  >
                    <div className="card-body row py-0">
                      <div className="col-md-4 px-0">
                        <img
                          src="https://c4.wallpaperflare.com/wallpaper/241/699/670/274-apartment-condo-design-wallpaper-preview.jpg"
                          alt="wallpaper"
                          className="img-fluid h-100 object-cover"
                        />
                      </div>
                      <div className="col-md-8 pe-4 py-2">
                        <div className="card-body p-0 h-100 d-flex flex-column justify-content-between">
                          <div>
                            <h4 className="d-flex justify-content-between align-items-center">
                              <span>
                                {v.name}{" "}
                                <i className="bi-star-fill text-warning fs-6 cursor-pointer"></i>
                              </span>
                              <small className="fs-6">{v.sqftPrice}/sqft</small>
                            </h4>
                            <h6>CA {v.price}</h6>
                            <section>
                              <span className="bg-dark text-white small px-2 py-1 rounded">
                                For {v.transaction}
                              </span>
                              <span className="bg-primary text-white small px-2 py-1 mx-2 rounded">
                                Featured
                              </span>
                            </section>
                            <p className="card-text my-2">{v.description}</p>
                          </div>
                          <div className="d-flex justify-content-between align-items-center">
                            <div className="btn-group">
                              <button
                                type="button"
                                className="btn btn-sm border-0 shadow-none px-0"
                              >
                                {v.features.beds} bed(s)
                              </button>
                              <button
                                type="button"
                                className="btn btn-sm border-0 shadow-none"
                              >
                                {v.features.baths} bath(s)
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
            <div className="col-md-6">
              {coords.length > 0 && (
                <div className="position-sticky" style={{ top: "2rem" }}>
                  <MapContainer
                    center={[coords[0].lat, coords[0].lng]}
                    zoom={13}
                    style={{ height: "500px" }}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    {coords.map((coord, i) => (
                      <Marker
                        position={[coord.lat, coord.lng]}
                        key={i}
                        icon={iconPoint}
                      >
                        <Popup>{coord.title}</Popup>
                      </Marker>
                    ))}
                  </MapContainer>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </Header>
  );
}
