import axios from "axios";
import { useEffect, useState } from "react";

export default function SavedSearch() {
  const [token] = useState(localStorage.getItem("realtor-token"));
  const [search, setSearch] = useState([]);

  useEffect(() => {
    axios
      .get("/search/saved", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        if (res.status === 200) {
          setSearch([...res.data]);
        }
      })
      .catch(() => {
        alert("Something went wrong");
      });
  }, []);

  return (
    <div className="my-3 mx-5 p-3 bg-body rounded shadow-sm">
      <h4 className="border-bottom pb-2 mb-0">Saved Search</h4>
      {search.length === 0 && <h3>No results found</h3>}
      {search.length > 0 &&
        search.map((s, i) => (
          <div className="d-flex text-muted pt-3" key={i}>
            <div
              className={`mb-0 small lh-sm w-100 ${
                i !== search.length - 1 && "pb-3 border-bottom"
              }`}
            >
              <div className="d-flex justify-content-between">
                <strong className="text-gray-dark">{s.searchBy}</strong>
                <span className="text-muted small">
                  {"Last saved on: " +
                    s.savedOn.substr(0, 10) +
                    " " +
                    s.savedOn.substr(11, 8)}
                </span>
              </div>
            </div>
          </div>
        ))}
    </div>
  );
}
