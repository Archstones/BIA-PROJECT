export default function SavedSearch() {
  return (
    <div className="my-3 mx-5 p-3 bg-body rounded shadow-sm">
      <h4 className="border-bottom pb-2 mb-0">Saved Search</h4>
      {Array(100)
        .fill(0)
        .map((v, i) => (
          <div className="d-flex text-muted pt-3">
            <div
              className={`mb-0 small lh-sm border-bottom w-100 ${
                i !== 99 && "pb-3 border-bottom"
              }`}
            >
              <div className="d-flex justify-content-between">
                <strong className="text-gray-dark">Search Result {i+1}</strong>
                <i className="bi-trash cursor-pointer text-danger"></i>
              </div>
            </div>
          </div>
        ))}
    </div>
  );
}
