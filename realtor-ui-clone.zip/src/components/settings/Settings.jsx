import { Fragment } from "react";
import { Outlet, NavLink } from "react-router-dom";
import { APP_NAME } from "../../config/app.config";

export default function Settings() {
  return (
    <Fragment>
      <div className="container-fluid h-100">
        <div className="row h-100">
          <div
            className="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark h-100"
            style={{ width: "280px" }}
          >
            <NavLink
              to={"/"}
              className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none"
            >
              <span className="fs-4">{APP_NAME}</span>
            </NavLink>
            <hr />
            <ul className="nav nav-pills flex-column mb-auto">
              <li className="nav-item">
                <NavLink to="add-listing" className="nav-link text-white">
                  Create Listing
                </NavLink>
              </li>
              <li>
                <NavLink to="favorites" className="nav-link text-white">
                  My Favorites
                </NavLink>
              </li>
              <li>
                <NavLink to="invoices" className="nav-link text-white">
                  Invoices
                </NavLink>
              </li>
              <li>
                <NavLink to="update-profile" className="nav-link text-white">
                  My Profile
                </NavLink>
              </li>
              <li>
                <NavLink to="properties" className="nav-link text-white">
                  My Properties
                </NavLink>
              </li>
              <li>
                <NavLink to="all-properties" className="nav-link text-white">
                  All Properties
                </NavLink>
              </li>
              <li>
                <NavLink to="saved-search" className="nav-link text-white">
                  Saved Search
                </NavLink>
              </li>
            </ul>
            <hr />
            <div>
              <NavLink
                to="logout"
                className="d-flex justify-content-between text-white text-decoration-none"
              >
                Sign out <i className="bi-box-arrow-right"></i>
              </NavLink>
            </div>
          </div>
          <div className="col overflow-auto h-100">
            <Outlet />
          </div>
        </div>
      </div>
    </Fragment>
  );
}
