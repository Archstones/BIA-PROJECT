import { Link } from "react-router-dom";

export function PropertyCard() {
  return (
    <div className="col-md-4 my-3">
      <Link to={"/property/12345"} className="text-decoration-none text-black">
        <div className="card shadow-sm">
          <img
            src="https://c4.wallpaperflare.com/wallpaper/241/699/670/274-apartment-condo-design-wallpaper-preview.jpg"
            alt="wallpaper"
          />
          <div className="card-body">
            <h4 className="d-flex justify-content-between align-items-center">
              <span>
                Property name{" "}
                <i className="bi-star-fill text-warning fs-6 cursor-pointer"></i>
              </span>
              <small className="fs-6">1200/sqft</small>
            </h4>
            <h6>$25,000</h6>
            <section className="d-flex justify-content-between">
              <span className="bg-dark text-white small px-2 py-1 rounded">
                For Sale
              </span>
              <span className="bg-primary text-white small px-2 py-1 rounded">
                Featured
              </span>
            </section>
            <p className="card-text my-2">
              This is a wider card with supporting text below as a natural
              lead-in to additional content. This content is a little bit
              longer.
            </p>
            <div className="d-flex justify-content-between align-items-center">
              <div className="btn-group">
                <button
                  type="button"
                  className="btn btn-sm border-0 shadow-none px-0"
                >
                  3 bed(s)
                </button>
                <button
                  type="button"
                  className="btn btn-sm border-0 shadow-none"
                >
                  1 bath(s)
                </button>
              </div>
              <small className="text-muted">9 mins ago</small>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}
