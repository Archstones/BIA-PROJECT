import { Link } from "react-router-dom";
import axios from "axios";

export function PropertyCard(props) {
  return (
    <div className="col-md-4 my-3">
      <Link
        to={`/property/${props.details._id}`}
        className="text-decoration-none text-black"
      >
        <div
          className="card shadow-sm"
          style={{
            maxHeight: "300px",
            minHeight: "500px",
            overflowY: "auto",
          }}
        >
          <img
            src={`${axios.defaults.baseURL}property/image?id=${props.details.images[0]}&token=${props.token}`}
            alt="wallpaper"
            style={{
              maxHeight: "250px",
              objectFit: "cover",
            }}
          />
          <div className="card-body d-flex flex-column justify-content-between">
            <div>
              <h4 className="d-flex justify-content-between align-items-center">
                <span>
                  {props.details.name}
                  {!props.hideFav && (
                    <i className="bi-star-fill text-warning fs-6 cursor-pointer"></i>
                  )}
                </span>
                <small className="fs-6">{props.details.sqftPrice}/sqft</small>
              </h4>
              <h6>CA {props.details.price}</h6>
              <section className="d-flex justify-content-between">
                <span className="bg-dark text-white small px-2 py-1 rounded">
                  For {props.details.transaction}
                </span>
                <span className="bg-primary text-white small px-2 py-1 rounded">
                  Featured
                </span>
              </section>
              <p className="card-text my-2">{props.details.description}</p>
            </div>
            <div className="d-flex justify-content-between align-items-center">
              <div className="btn-group">
                <button
                  type="button"
                  className="btn btn-sm border-0 shadow-none px-0"
                >
                  {props.details.features.beds} bed(s)
                </button>
                <button
                  type="button"
                  className="btn btn-sm border-0 shadow-none"
                >
                  {props.details.features.baths} bath(s)
                </button>
              </div>
              {/* <small className="text-muted">9 mins ago</small> */}
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}
