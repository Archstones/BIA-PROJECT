import { PropertyCard } from "./PropertyCard";

export default function MyProperty() {
  return (
    <section>
      <h3 className="p-3">My Properties</h3>
      <div className="container">
        <div className="row">
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
        </div>
      </div>
    </section>
  );
}
