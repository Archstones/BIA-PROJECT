import axios from "axios";
import { useEffect, useState } from "react";
import { PropertyCard } from "./PropertyCard";

export default function AllProperty() {
  const [token] = useState(localStorage.getItem("realtor-token"));
  const [property, setProperty] = useState([]);

  useEffect(() => {
    axios
      .get("/property", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        if (res.status === 200) {
          setProperty([...res.data]);
        }
      })
      .catch(() => {
        alert("Something went wrong");
      });
  }, []);
  return (
    <section>
      <h3 className="p-3">All Properties</h3>
      <div className="container">
        <div className="row">
          {property.map((p, i) => (
            <PropertyCard details={p} hideFav={true} key={i} token={token} />
          ))}
        </div>
      </div>
    </section>
  );
}
