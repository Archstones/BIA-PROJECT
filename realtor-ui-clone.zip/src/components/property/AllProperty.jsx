import { PropertyCard } from "./PropertyCard";

export default function AllProperty() {
  return (
    <section>
      <h3 className="p-3">All Properties</h3>
      <div className="container">
        <div className="row">
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
        </div>
      </div>
    </section>
  );
}
