import { PropertyCard } from "./PropertyCard";

function Favorites() {
  return (
    <section>
      <h3 className="p-3">My Favorites</h3>
      <div className="container">
        <div className="row">
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
          <PropertyCard />
        </div>
      </div>
    </section>
  );
}

export default Favorites;
