import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import Header from "../nav/Header";

function PropertyDetail() {
  const params = useParams();
  const [token] = useState(localStorage.getItem("realtor-token"));
  const [property, setProperty] = useState({});
  const [image, setImage] = useState("");

  useEffect(() => {
    axios
      .get(`/property/${params.propertyId}/details`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((res) => {
        if (res.status === 200) {
          setProperty({ ...res.data });
          setImage(res.data.images[0]);
        }
      })
      .catch(() => {
        alert("Something went wrong");
      });
  }, []);
  return (
    <Header noFooter>
      <main className="container bg-white rounded px-5 py-4">
        <div className="row">
          <Link to={"/home"} className="py-2 text-decoration-none">
            &laquo; Back to home
          </Link>
        </div>
        <div className="d-flex justify-content-between align-items-center">
          <div className="pt-4">
            <h2>{property.name}</h2>
            <section>
              <span className="bg-dark text-white small px-2 py-1 rounded">
                For {property.transaction}
              </span>
              <span className="bg-primary text-white small px-2 py-1 mx-2 rounded">
                Featured
              </span>
            </section>
            <p className="text-muted small fs-6 mt-2 mb-0">{`${property?.address?.street}, ${property?.address?.city}, ${property?.address?.state}, ${property?.address?.country}`}</p>
          </div>
          <div className="text-end">
            <i
              className={`bi-star-fill fs-6 cursor-pointer ${
                property?.favorite ? "text-warning" : "text-black"
              }`}
              onClick={() => {
                axios
                  .post(
                    `/property/favorite`,
                    { property: params.propertyId },
                    {
                      headers: {
                        Authorization: `Bearer ${token}`,
                      },
                    }
                  )
                  .then((res) => {
                    if (res.status === 200) {
                      setProperty({ ...property, favorite: res.data.status });
                    }
                  })
                  .catch(() => {
                    alert("Something went wrong");
                  });
              }}
            ></i>
            <h1>CA {property.price}</h1>
            <h6 className="text-muted text-end">{property.sqftPrice}/sqft</h6>
          </div>
        </div>

        {property && (
          <div className="row mt-3">
            <div className="col-md-9">
              <img
                src={`${axios.defaults.baseURL}property/image?id=${image}&token=${token}`}
                className="img-fluid"
                alt="main property"
                style={{
                  maxHeight: "550px",
                  objectFit: "cover",
                  width: "100%",
                }}
              />
            </div>
            <div className="col-md-3">
              <div className="row h-100 flex-column justify-content-between">
                {property?.images?.slice(0, 3).map((propertyImage, index) => (
                  <div
                    className="col-md-12 cursor-pointer"
                    key={index}
                    onClick={() => setImage(propertyImage)}
                  >
                    <img
                      src={`${axios.defaults.baseURL}property/image?id=${propertyImage}&token=${token}`}
                      className="img-fluid"
                      alt="other property"
                      style={{
                        maxHeight: "180px",
                        objectFit: "cover",
                        width: "100%",
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="row mt-3 g-5">
          <div className="col-md-8">
            <h3 className="pb-4 fst-italic">From the seller</h3>
            <div className="row text-center border-bottom mb-4 pb-4">
              <div className="col">
                <h5>{property.type}</h5>
                <span>Property type</span>
              </div>
              <div className="col">
                <h5>{property.transaction}</h5>
                <span>Type</span>
              </div>
              <div className="col">
                <h5>{property?.features?.beds}</h5>
                <span>Bed(s)</span>
              </div>
              <div className="col">
                <h5>{property?.features?.baths}</h5>
                <span>Bath(s)</span>
              </div>
              <div className="col">
                <h5>{property?.features?.storeys}</h5>
                <span>Storey(s)</span>
              </div>
            </div>
            <article>
              <h2>Description</h2>
              <p>{property.description}</p>
              <hr />
              <h2>Amenities</h2>
              <p>{property.amenties}</p>
              <hr />
              <h2>Condition</h2>
              <p>{property.condition}</p>
            </article>
          </div>

          <div className="col-md-4">
            <div className="position-sticky" style={{ top: "2rem" }}>
              <div className="p-4 mb-3 bg-light rounded">
                <h4 className="fst-italic">Features</h4>
                {property?.features?.other?.length === 0 && (
                  <p>No feature added</p>
                )}
                {property?.features?.other?.length >= 0 && (
                  <ol>
                    {property?.features?.other.map((f, i) => (
                      <li key={i}>{f}</li>
                    ))}
                  </ol>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
    </Header>
  );
}

export default PropertyDetail;
