import { useParams } from "react-router-dom";

function PropertyDetail() {
  const propertyId = useParams();
  //   console.log(propertyId);
  return (
    <main className="container">
      <div className="d-flex justify-content-between align-items-center">
        <div className="pt-4">
          <h2>Property name</h2>
          <section>
            <span className="bg-dark text-white small px-2 py-1 rounded">
              For Sale
            </span>
            <span className="bg-primary text-white small px-2 py-1 mx-2 rounded">
              Featured
            </span>
          </section>
          <p className="text-muted small fs-6 mt-2 mb-0">address here</p>
        </div>
        <div className="text-end">
          <i className="bi-star-fill text-warning fs-6 cursor-pointer"></i>
          <h1>25,000</h1>
          <h6 className="text-muted text-end">2500/sqft</h6>
        </div>
      </div>

      <div className="row mt-3">
        <div className="col-md-9">
          <img
            src="https://source.unsplash.com/collection/190726/1500x900"
            className="img-fluid"
            alt="image"
          />
        </div>
        <div className="col-md-3">
          <div className="row h-100 flex-column justify-content-between">
            <div className="col-md-12 cursor-pointer">
              <img
                src="https://source.unsplash.com/collection/190726/1500x900"
                className="img-fluid"
                alt="image"
              />
            </div>
            <div className="col-md-12 cursor-pointer">
              <img
                src="https://source.unsplash.com/collection/190726/1500x900"
                className="img-fluid"
                alt="image"
              />
            </div>
            <div className="col-md-12 cursor-pointer">
              <img
                src="https://source.unsplash.com/collection/190726/1500x900"
                className="img-fluid"
                alt="image"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-3 g-5">
        <div className="col-md-8">
          <h3 className="pb-4 fst-italic">From the seller</h3>
          <div className="row text-center border-bottom mb-4 pb-4">
            <div className="col">
              <h5>Commercial</h5>
              <span>Property type</span>
            </div>
            <div className="col">
              <h5>Sale</h5>
              <span>Type</span>
            </div>
            <div className="col">
              <h5>6</h5>
              <span>Bed(s)</span>
            </div>
            <div className="col">
              <h5>6</h5>
              <span>Bath(s)</span>
            </div>
            <div className="col">
              <h5>6</h5>
              <span>Storey(s)</span>
            </div>
          </div>
          <article>
            <h2>Description</h2>
            <p>
              This blog post shows a few different types of content that’s
              supported and styled with Bootstrap. Basic typography, lists,
              tables, images, code, and more are all supported as expected.
            </p>
            <hr />
            <h2>Amenities</h2>
            <p>
              This is some additional paragraph placeholder content. It has been
              written to fill the available space and show how a longer snippet
              of text affects the surrounding content. We'll repeat it often to
              keep the demonstration flowing, so be on the lookout for this
              exact same string of text.
            </p>
            <hr />
            <h2>Condition</h2>
            <p>
              This is some additional paragraph placeholder content. It has been
              written to fill the available space and show how a longer snippet
              of text affects the surrounding content. We'll repeat it often to
              keep the demonstration flowing, so be on the lookout for this
              exact same string of text.
            </p>
          </article>
        </div>

        <div className="col-md-4">
          <div className="position-sticky" style={{ top: "2rem" }}>
            <div className="p-4 mb-3 bg-light rounded">
              <h4 className="fst-italic">Features</h4>
              <ol>
                <li>Chair</li>
                <li>Chair</li>
                <li>Chair</li>
                <li>Chair</li>
                <li>Chair</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

export default PropertyDetail;
