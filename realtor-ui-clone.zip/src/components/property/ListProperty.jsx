import { PropertyCard } from "./PropertyCard";

function ListProperty() {
  return (
    <div className="row">
      <PropertyCard />
      <PropertyCard />
      <PropertyCard />
      <PropertyCard />
    </div>
  );
}

export default ListProperty;
