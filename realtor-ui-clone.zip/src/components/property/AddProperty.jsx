import axios from "axios";
import { useState } from "react";

const initialValue = {
  name: "",
  description: "",
  amenties: "",
  condition: "",
  type: "Commercial",
  transaction: "Sale",
  dimension: {
    height: 0,
    width: 0,
    length: 0,
  },
  address: {
    street: "",
    city: "",
    state: "",
    country: "",
    zipcode: "",
    latitude: 0.0,
    longitude: 0.0,
  },
  price: 0,
  sqftPrice: 0,
  features: {
    beds: 1,
    baths: 1,
    landsize: 0,
    storeys: 1,
    other: [],
  },
};

function AddProperty() {
  const [property, setProperty] = useState({ ...initialValue });
  const [images, setImages] = useState([]);
  return (
    <section>
      <h3 className="p-3">Add Property</h3>
      <div className="container h-100">
        <div className="row justify-content-center h-100">
          <form
            className="px-3"
            onSubmit={(ev) => {
              const authToken = localStorage.getItem("realtor-token");
              const formData = new FormData();
              formData.append("data", JSON.stringify({ ...property }));
              images.forEach((image) => {
                formData.append("property", image);
              });
              ev.preventDefault();
              axios
                .post("/property/add-new", formData, {
                  headers: {
                    Authorization: `Bearer ${authToken}`,
                  },
                })
                .then((res) => {
                  if (res.status === 200) {
                    setProperty({ ...initialValue });
                    setImages([]);
                    window.alert(res.data.message);
                  }
                })
                .catch(() => {
                  alert("Something went wrong");
                });
            }}
          >
            <div className="col-md-12">
              <div className="my-2 bg-white fw-normal border-0 fs-5">
                Basic Details
              </div>
              <div className="card">
                <div className="card-body">
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="name" className="form-label">
                        Property name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            name: ev.target.value,
                          })
                        }
                        value={property.name}
                      />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="description" className="form-label">
                        Description
                      </label>
                      <textarea
                        name="description"
                        id="description"
                        rows="4"
                        className="form-control"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            description: ev.target.value,
                          })
                        }
                        value={property.description}
                      ></textarea>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="amenity" className="form-label">
                        Amenties
                      </label>
                      <textarea
                        name="amenity"
                        id="amenity"
                        rows="4"
                        className="form-control"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            amenties: ev.target.value,
                          })
                        }
                        value={property.amenties}
                      ></textarea>
                    </div>
                    <div className="col">
                      <label htmlFor="condition" className="form-label">
                        Condition
                      </label>
                      <textarea
                        name="condition"
                        id="condition"
                        rows="4"
                        className="form-control"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            condition: ev.target.value,
                          })
                        }
                        value={property.condition}
                      ></textarea>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="building-type" className="form-label">
                        Building Type
                      </label>
                      <select
                        name="building-type"
                        id="building-type"
                        className="form-select"
                        onChange={(ev) =>
                          setProperty({
                            ...property,
                            type: ev.target.value,
                          })
                        }
                        value={property.type}
                      >
                        <option value="Commercial">Commercial</option>
                        <option value="Residential">Residential</option>
                      </select>
                    </div>
                    <div className="col">
                      <label htmlFor="transaction-type" className="form-label">
                        Transaction Type
                      </label>
                      <select
                        name="transaction-type"
                        id="transaction-type"
                        className="form-select"
                        onChange={(ev) =>
                          setProperty({
                            ...property,
                            transaction: ev.target.value,
                          })
                        }
                        value={property.transaction}
                      >
                        <option value="Sale">Sale</option>
                        <option value="Rent">Rent</option>
                      </select>
                    </div>
                    <div className="col">
                      <label htmlFor="Dimension" className="form-label">
                        Dimension
                      </label>
                      <div className="row">
                        <div className="col">
                          <input
                            type="number"
                            name="height"
                            id="height"
                            className="form-control"
                            placeholder="Height"
                            onInput={(ev) =>
                              setProperty({
                                ...property,
                                dimension: {
                                  ...property.dimension,
                                  height: ev.target.value,
                                },
                              })
                            }
                            value={property.dimension.height}
                          />
                        </div>
                        <div className="col">
                          <input
                            type="number"
                            name="width"
                            id="width"
                            className="form-control"
                            placeholder="Width"
                            onInput={(ev) =>
                              setProperty({
                                ...property,
                                dimension: {
                                  ...property.dimension,
                                  width: ev.target.value,
                                },
                              })
                            }
                            value={property.dimension.width}
                          />
                        </div>
                        <div className="col">
                          <input
                            type="number"
                            name="length"
                            id="length"
                            className="form-control"
                            placeholder="Length"
                            onInput={(ev) =>
                              setProperty({
                                ...property,
                                dimension: {
                                  ...property.dimension,
                                  length: ev.target.value,
                                },
                              })
                            }
                            value={property.dimension.length}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="mt-5" />
            <div className="col-md-12">
              <div className="my-2 bg-white fw-normal border-0 fs-5">
                Address
              </div>
              <div className="card">
                <div className="card-body">
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="street" className="form-label">
                        Street
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="street"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            address: {
                              ...property.address,
                              street: ev.target.value,
                            },
                          })
                        }
                        value={property.address.street}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="city" className="form-label">
                        City
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="city"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            address: {
                              ...property.address,
                              city: ev.target.value,
                            },
                          })
                        }
                        value={property.address.city}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="state" className="form-label">
                        State
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="state"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            address: {
                              ...property.address,
                              state: ev.target.value,
                            },
                          })
                        }
                        value={property.address.state}
                      />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="country" className="form-label">
                        Country
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="country"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            address: {
                              ...property.address,
                              country: ev.target.value,
                            },
                          })
                        }
                        value={property.address.country}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="zipcode" className="form-label">
                        Zipcode
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="zipcode"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            address: {
                              ...property.address,
                              zipcode: ev.target.value,
                            },
                          })
                        }
                        value={property.address.zipcode}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="price" className="form-label">
                        Price <span className="text-danger">**</span>
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="price"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            price: ev.target.value,
                          })
                        }
                        value={property.price}
                      />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="sqftprice" className="form-label">
                        Sqft price <span className="text-danger">**</span>
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="sqftprice"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            sqftPrice: ev.target.value,
                          })
                        }
                        value={property.sqftPrice}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="latitude" className="form-label">
                        Latitude
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="latitude"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            address: {
                              ...property.address,
                              latitude: ev.target.value,
                            },
                          })
                        }
                        value={property.address.latitude}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="longitude" className="form-label">
                        Longitude
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="longitude"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            address: {
                              ...property.address,
                              longitude: ev.target.value,
                            },
                          })
                        }
                        value={property.address.longitude}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="mt-5" />
            <div className="col-md-12">
              <div className="my-2 bg-white fw-normal border-0 fs-5">
                Features
              </div>
              <div className="card">
                <div className="card-body">
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="bed" className="form-label">
                        Beds
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="bed"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            features: {
                              ...property.features,
                              beds: ev.target.value,
                            },
                          })
                        }
                        value={property.features.beds}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="bath" className="form-label">
                        Baths
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="bath"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            features: {
                              ...property.features,
                              baths: ev.target.value,
                            },
                          })
                        }
                        value={property.features.baths}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="landsize" className="form-label">
                        Landsize
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="landsize"
                        placeholder="In acres"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            features: {
                              ...property.features,
                              landsize: ev.target.value,
                            },
                          })
                        }
                        value={property.features.landsize}
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="storeys" className="form-label">
                        Storeys
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="storeys"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            features: {
                              ...property.features,
                              storeys: ev.target.value,
                            },
                          })
                        }
                        value={property.features.storeys}
                      />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="other-feature" className="form-label">
                        Other Features
                      </label>
                      <select
                        className="form-control"
                        id="other-feature"
                        onInput={(ev) =>
                          setProperty({
                            ...property,
                            features: {
                              ...property.features,
                              other: Array.from(
                                new Set([
                                  ...property.features.other,
                                  ev.target.value,
                                ])
                              ),
                            },
                          })
                        }
                        multiple
                        value={property.features.other}
                      ></select>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-12">
                      <label
                        htmlFor="additional-details"
                        className="form-label"
                      >
                        Additional Details
                      </label>
                      <div className="row">
                        <div className="col">
                          <input type="text" className="form-control" />
                        </div>
                        <div className="col">
                          <input type="text" className="form-control" />
                        </div>
                        <div className="col">
                          <button className="btn btn-primary">Add</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <hr className="mt-5" />
            <div className="col-md-12">
              <div className="my-2 bg-white fw-normal border-0 fs-5">
                Upload Property Images
              </div>
              <div className="card">
                <div className="card-body">
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="images" className="form-label">
                        Select Images
                      </label>
                      <input
                        type="file"
                        multiple
                        className="form-control"
                        id="images"
                        onChange={(ev) => setImages([...ev.target.files])}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="my-5">
              <button type="submit" className="btn btn-primary">
                Save Property
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}

export default AddProperty;
