function AddProperty() {
  return (
    <section>
      <h3 className="p-3">Add Property</h3>
      <div className="container h-100">
        <div className="row justify-content-center h-100">
          <div className="col-md-12">
            <div className="my-2 bg-white fw-normal border-0 fs-5">
              Basic Details
            </div>
            <div className="card">
              <div className="card-body">
                <form className="px-3">
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="name" className="form-label">
                        Property name
                      </label>
                      <input type="text" className="form-control" id="name" />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="description" className="form-label">
                        Description
                      </label>
                      <textarea
                        name="description"
                        id="description"
                        rows="4"
                        className="form-control"
                      ></textarea>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="amenity" className="form-label">
                        Amenties
                      </label>
                      <textarea
                        name="amenity"
                        id="amenity"
                        rows="4"
                        className="form-control"
                      ></textarea>
                    </div>
                    <div className="col">
                      <label htmlFor="condition" className="form-label">
                        Condition
                      </label>
                      <textarea
                        name="condition"
                        id="condition"
                        rows="4"
                        className="form-control"
                      ></textarea>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="building-type" className="form-label">
                        Building Type
                      </label>
                      <select
                        name="building-type"
                        id="building-type"
                        className="form-select"
                      >
                        <option value="Commercial">Commercial</option>
                        <option value="Residential">Residential</option>
                      </select>
                    </div>
                    <div className="col">
                      <label htmlFor="transaction-type" className="form-label">
                        Transaction Type
                      </label>
                      <select
                        name="transaction-type"
                        id="transaction-type"
                        className="form-select"
                      >
                        <option value="Sale">Sale</option>
                        <option value="Rent">Rent</option>
                      </select>
                    </div>
                    <div className="col">
                      <label htmlFor="Dimension" className="form-label">
                        Dimension
                      </label>
                      <div className="row">
                        <div className="col">
                          <input
                            type="number"
                            name="height"
                            id="height"
                            className="form-control"
                            placeholder="Height"
                          />
                        </div>
                        <div className="col">
                          <input
                            type="number"
                            name="width"
                            id="width"
                            className="form-control"
                            placeholder="Width"
                          />
                        </div>
                        <div className="col">
                          <input
                            type="number"
                            name="length"
                            id="length"
                            className="form-control"
                            placeholder="Length"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <hr className="mt-5" />
          <div className="col-md-12">
            <div className="my-2 bg-white fw-normal border-0 fs-5">Address</div>
            <div className="card">
              <div className="card-body">
                <form className="px-3">
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="street" className="form-label">
                        Street
                      </label>
                      <input type="text" className="form-control" id="street" />
                    </div>
                    <div className="col">
                      <label htmlFor="city" className="form-label">
                        City
                      </label>
                      <input type="text" className="form-control" id="city" />
                    </div>
                    <div className="col">
                      <label htmlFor="state" className="form-label">
                        State
                      </label>
                      <input type="text" className="form-control" id="state" />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="country" className="form-label">
                        Country
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="country"
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="zipcode" className="form-label">
                        Zipcode
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="zipcode"
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="price" className="form-label">
                        Price <span className="text-danger">**</span>
                      </label>
                      <input type="text" className="form-control" id="price" />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="sqftprice" className="form-label">
                        Sqft price <span className="text-danger">**</span>
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="sqftprice"
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="latitude" className="form-label">
                        Latitude
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="latitude"
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="longitude" className="form-label">
                        Longitude
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="longitude"
                      />
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <hr className="mt-5" />
          <div className="col-md-12">
            <div className="my-2 bg-white fw-normal border-0 fs-5">
              Features
            </div>
            <div className="card">
              <div className="card-body">
                <form className="px-3">
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="bed" className="form-label">
                        Beds
                      </label>
                      <input type="number" className="form-control" id="bed" />
                    </div>
                    <div className="col">
                      <label htmlFor="bath" className="form-label">
                        Baths
                      </label>
                      <input type="number" className="form-control" id="bath" />
                    </div>
                    <div className="col">
                      <label htmlFor="landsize" className="form-label">
                        Landsize
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="landsize"
                        placeholder="In acres"
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="storeys" className="form-label">
                        Storeys
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="storeys"
                      />
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <label htmlFor="other-feature" className="form-label">
                        Other Features
                      </label>
                      <select
                        className="form-control"
                        id="other-feature"
                      ></select>
                    </div>
                  </div>
                  <div className="row mb-3">
                    <div className="col-md-12">
                      <label
                        htmlFor="additional-details"
                        className="form-label"
                      >
                        Additional Details
                      </label>
                      <div className="row">
                        <div className="col">
                          <input type="text" className="form-control" />
                        </div>
                        <div className="col">
                          <input type="text" className="form-control" />
                        </div>
                        <div className="col">
                          <button className="btn btn-primary">Add</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <hr className="mt-5" />
          <div className="col-md-12">
            <div className="my-2 bg-white fw-normal border-0 fs-5">
              Upload Property Images
            </div>
            <div className="card">
              <div className="card-body">
                <form className="px-3">
                  <div className="row mb-3">
                    <div className="col">
                      <label htmlFor="images" className="form-label">
                        Select Images
                      </label>
                      <input
                        type="file"
                        multiple
                        className="form-control"
                        id="images"
                      />
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className="my-5">
            <button type="submit" className="btn btn-primary">
              Save Property
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default AddProperty;
