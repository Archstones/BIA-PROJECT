import { Fragment } from "react";
import { Link } from "react-router-dom";
import { APP_NAME } from "../config/app.config";
import { PropertyCard } from "./property/PropertyCard";

function Home() {
  return (
    <Fragment>
      <div
        className="container-fluid w-100 h-100"
        style={{
          backgroundImage: `url(${"https://layjao.com/wp-content/uploads/2018/12/more-5-easy-modern-cream-living-room-ideas-cream-leather-sofa-which.jpg"})`,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
        }}
      >
        <div className="container d-flex mx-auto flex-column">
          <header className="mb-5 py-4">
            <div>
              <h3 className="float-md-start mb-0">{APP_NAME}</h3>
              <nav className="nav justify-content-center float-md-end">
                <Link to={"/login"} className="nav-link text-dark">
                  Login
                </Link>
                <Link to={"/signup"} className="nav-link text-dark">
                  Signup
                </Link>
              </nav>
            </div>
          </header>

          <main className="px-3 mt-5">
            <h3>Search the best class property for rent</h3>
            <div class="input-group input-group-lg">
              <input
                type="text"
                class="form-control"
                aria-label="Sizing example input"
                aria-describedby="inputGroup-sizing-lg"
              />
              <button className="btn bg-dark shadow-none text-white">
                Search
              </button>
            </div>
          </main>
        </div>
      </div>
      <footer className="mt-auto bg-dark text-white p-3 position-sticky">
        <span>&copy; {APP_NAME} 2022</span>
      </footer>
    </Fragment>
  );
}

export default Home;
