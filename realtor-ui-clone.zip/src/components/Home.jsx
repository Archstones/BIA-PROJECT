import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "./nav/Header";

function Home() {
  const [place, setPlace] = useState();
  const navigate = useNavigate();
  return (
    <Header>
      <main className="px-3 mt-5">
        <h3>Search the best class property for rent</h3>
        <div className="input-group input-group-lg">
          <input
            type="text"
            className="form-control"
            aria-label="Sizing example input"
            aria-describedby="inputGroup-sizing-lg"
            placeholder="Search by property name, city, state, etc"
            onInput={(ev) => setPlace(ev.target.value)}
          />
          <button
            className="btn bg-dark shadow-none text-white"
            onClick={() => {
              if (place) {
                navigate(`/search/results?query=${place}`, { replace: true });
              } else {
                window.alert("Please enter valid place");
              }
            }}
          >
            Search
          </button>
        </div>
      </main>
    </Header>
  );
}

export default Home;
