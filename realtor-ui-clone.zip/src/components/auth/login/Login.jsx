import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../nav/Header";

function Login() {
  const navigate = useNavigate();
  const [userInfo, setUserInfo] = useState({
    email: "",
    password: "",
  });
  useEffect(() => {
    const authToken = localStorage.getItem("realtor-token");
    if (authToken) {
      navigate("/home", { replace: true });
    }
  }, []);
  return (
    <Header>
      <section className="h-100">
        <div className="container h-100">
          <div className="row justify-content-center align-items-center h-100">
            <div className="col-md-6">
              <div className="card">
                <div className="card-header bg-white fw-normal text-center border-0 fs-4">
                  Login
                </div>
                <div className="card-body">
                  <form
                    className="px-5"
                    onSubmit={(ev) => {
                      ev.preventDefault();
                      axios
                        .post("/auth/login", {
                          ...userInfo,
                        })
                        .then((res) => {
                          if (res.status === 200) {
                            alert(res.data.message);
                            const email = res.data.email;
                            const token = res.data.token;
                            const name = res.data.name;
                            localStorage.setItem("realtor-username", name);
                            localStorage.setItem("realtor-email", email);
                            localStorage.setItem("realtor-token", token);
                            localStorage.setItem(
                              "realtor-isauthenticated",
                              true
                            );
                            navigate("/home", { replace: true });
                          }
                        })
                        .catch(() => {
                          alert("Something went wrong");
                        });
                    }}
                  >
                    <div className="mb-3">
                      <label htmlFor="email" className="form-label">
                        Email address
                      </label>
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        value={userInfo.email}
                        onInput={(ev) =>
                          setUserInfo({
                            ...userInfo,
                            email: ev.target.value,
                          })
                        }
                        aria-describedby="emailHelp"
                      />
                      <div id="emailHelp" className="form-text">
                        We'll never share your email with anyone else.
                      </div>
                    </div>
                    <div className="mb-3">
                      <label htmlFor="password" className="form-label">
                        Password
                      </label>
                      <input
                        type="password"
                        className="form-control"
                        id="password"
                        value={userInfo.password}
                        onInput={(ev) =>
                          setUserInfo({
                            ...userInfo,
                            password: ev.target.value,
                          })
                        }
                      />
                    </div>
                    <button
                      type="submit"
                      className="btn btn-primary text-white bg-black shadow-none"
                    >
                      Login
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Header>
  );
}

export default Login;
