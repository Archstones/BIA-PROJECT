import UpdateProfile from "./UpdateProfile";
import UpdatePassword from "./UpdatePassword";

function Profile() {
  return (
    <section>
      <h3 className="p-3">Profile</h3>
      <div className="container h-100">
        <div className="row justify-content-center h-100 mb-5">
          <div className="col-md-12">
            <div className="my-2 bg-white fw-normal border-0 fs-5">
              Update Profile
            </div>
            <UpdateProfile />
          </div>
          <hr className="mt-5" />
          <div className="col-md-12">
            <div className="my-2 bg-white fw-normal border-0 fs-5">
              Update Password
            </div>
            <UpdatePassword />
          </div>
        </div>
      </div>
    </section>
  );
}

export default Profile;
