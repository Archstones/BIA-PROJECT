function UpdatePassword() {
  return (
    <div className="card">
      <div className="card-body">
        <form className="px-3">
          <div className="col-6 mb-3">
            <div>
              <label htmlFor="current-password" className="form-label">
                Current Password
              </label>
              <input
                type="password"
                className="form-control"
                id="current-password"
              />
            </div>
            <div>
              <label htmlFor="new-password" className="form-label">
                New Password
              </label>
              <input
                type="password"
                className="form-control"
                id="new-password"
              />
            </div>
            <div>
              <label htmlFor="repeat-password" className="form-label">
                Repeat Password
              </label>
              <input
                type="text"
                className="form-control"
                id="repeat-password"
              />
            </div>
          </div>
          <button type="submit" className="btn btn-primary">
            Update Password
          </button>
        </form>
      </div>
    </div>
  );
}

export default UpdatePassword;
