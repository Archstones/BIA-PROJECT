import axios from "axios";
import { useState } from "react";

function UpdatePassword() {
  const [password, setPassword] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  return (
    <div className="card">
      <div className="card-body">
        <form
          className="px-3"
          onSubmit={(ev) => {
            ev.preventDefault();
            const authToken = localStorage.getItem("realtor-token");
            axios
              .post(
                "/profile/update-password",
                {
                  ...password,
                },
                {
                  headers: {
                    Authorization: `Bearer ${authToken}`,
                  },
                }
              )
              .then((res) => {
                if (res.status === 200) {
                  setPassword({
                    oldPassword: "",
                    newPassword: "",
                    confirmPassword: "",
                  });
                  alert(res.data.message);
                }
              })
              .catch((err) => alert("Unable to change the password"));
          }}
        >
          <div className="col-6 mb-3">
            <div>
              <label htmlFor="current-password" className="form-label">
                Current Password
              </label>
              <input
                type="password"
                className="form-control"
                id="current-password"
                value={password.oldPassword}
                onInput={(ev) =>
                  setPassword({
                    ...password,
                    oldPassword: ev.target.value,
                  })
                }
              />
            </div>
            <div>
              <label htmlFor="new-password" className="form-label">
                New Password
              </label>
              <input
                type="password"
                className="form-control"
                id="new-password"
                value={password.newPassword}
                onInput={(ev) =>
                  setPassword({
                    ...password,
                    newPassword: ev.target.value,
                  })
                }
              />
            </div>
            <div>
              <label htmlFor="repeat-password" className="form-label">
                Repeat Password
              </label>
              <input
                type="text"
                className="form-control"
                id="repeat-password"
                value={password.confirmPassword}
                onInput={(ev) =>
                  setPassword({
                    ...password,
                    confirmPassword: ev.target.value,
                  })
                }
              />
            </div>
          </div>
          <button type="submit" className="btn btn-primary">
            Update Password
          </button>
        </form>
      </div>
    </div>
  );
}

export default UpdatePassword;
