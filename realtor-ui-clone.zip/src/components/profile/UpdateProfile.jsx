import axios from "axios";
import { useEffect, useState } from "react";

function UpdateProfile() {
  const [profileInfo, setProfileInfo] = useState({
    email: "",
    fname: "",
    lname: "",
    city: "",
    country: "",
    postalCode: "",
    state: "",
    street: "",
    dob: "15-12-1997",
    phoneNumber: "",
  });

  useEffect(() => {
    const authToken = localStorage.getItem("realtor-token");
    axios
      .get("/profile", {
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      })
      .then((res) =>
        setProfileInfo({
          ...res.data,
        })
      )
      .catch((err) => alert("Unable to get the profile details"));
  }, []);

  return (
    <div className="card">
      <div className="card-body">
        <form
          className="px-3"
          onSubmit={(ev) => {
            ev.preventDefault();
            const authToken = localStorage.getItem("realtor-token");
            axios
              .post(
                "/profile/update",
                {
                  ...profileInfo,
                },
                {
                  headers: {
                    Authorization: `Bearer ${authToken}`,
                  },
                }
              )
              .then((res) => {
                if (res.status === 200) {
                  alert(res.data.message);
                }
              })
              .catch((err) => alert("Unable to update the profile details"));
          }}
        >
          <div className="row mb-3">
            <div className="col">
              <label htmlFor="firstname" className="form-label">
                First name
              </label>
              <input
                type="text"
                className="form-control"
                id="firstname"
                disabled
                value={profileInfo.fname}
              />
            </div>
            <div className="col">
              <label htmlFor="lastname" className="form-label">
                Last name
              </label>
              <input
                type="text"
                className="form-control"
                id="lastname"
                disabled
                value={profileInfo.lname}
              />
            </div>
            {/* <div className="col">
              <label htmlFor="dob" className="form-label">
                DOB
              </label>
              <input
                type="date"
                className="form-control"
                id="dob"
                value={profileInfo.dob}
                readOnly
              />
            </div> */}
          </div>
          <div className="row mb-3">
            <div className="col">
              <label htmlFor="email" className="form-label">
                Email address
              </label>
              <input
                type="email"
                className="form-control"
                id="email"
                aria-describedby="emailHelp"
                value={profileInfo.email}
                disabled
              />
              <div id="emailHelp" className="form-text">
                We'll never share your email with anyone else.
              </div>
            </div>
          </div>
          <div className="row mb-3">
            <div className="col">
              <label htmlFor="street" className="form-label">
                Street
              </label>
              <input
                type="text"
                className="form-control"
                id="street"
                value={profileInfo.street}
                onInput={(ev) =>
                  setProfileInfo({
                    ...profileInfo,
                    street: ev.target.value,
                  })
                }
              />
            </div>
            <div className="col">
              <label htmlFor="city" className="form-label">
                City
              </label>
              <input
                type="text"
                className="form-control"
                id="city"
                value={profileInfo.city}
                onInput={(ev) =>
                  setProfileInfo({
                    ...profileInfo,
                    city: ev.target.value,
                  })
                }
              />
            </div>
            <div className="col">
              <label htmlFor="state" className="form-label">
                State
              </label>
              <input
                type="text"
                className="form-control"
                id="state"
                value={profileInfo.state}
                onInput={(ev) =>
                  setProfileInfo({
                    ...profileInfo,
                    state: ev.target.value,
                  })
                }
              />
            </div>
          </div>
          <div className="row mb-3">
            <div className="col">
              <label htmlFor="country" className="form-label">
                Country
              </label>
              <input
                type="text"
                className="form-control"
                id="country"
                value={profileInfo.country}
                onInput={(ev) =>
                  setProfileInfo({
                    ...profileInfo,
                    country: ev.target.value,
                  })
                }
              />
            </div>
            <div className="col">
              <label htmlFor="zipcode" className="form-label">
                Zipcode
              </label>
              <input
                type="text"
                className="form-control"
                id="zipcode"
                value={profileInfo.postalCode}
                onInput={(ev) =>
                  setProfileInfo({
                    ...profileInfo,
                    postalCode: ev.target.value,
                  })
                }
              />
            </div>
            <div className="col">
              <label htmlFor="contact" className="form-label">
                Contact
              </label>
              <input
                type="text"
                className="form-control"
                id="contact"
                value={profileInfo.phoneNumber}
                onInput={(ev) =>
                  setProfileInfo({
                    ...profileInfo,
                    phoneNumber: ev.target.value,
                  })
                }
              />
            </div>
          </div>
          <button type="submit" className="btn btn-primary">
            Update Profile
          </button>
        </form>
      </div>
    </div>
  );
}

export default UpdateProfile;
