function UpdateProfile() {
  return (
    <div className="card">
      <div className="card-body">
        <form className="px-3">
          <div className="row mb-3">
            <div className="col">
              <label htmlFor="firstname" className="form-label">
                First name
              </label>
              <input type="text" className="form-control" id="firstname" />
            </div>
            <div className="col">
              <label htmlFor="lastname" className="form-label">
                Last name
              </label>
              <input type="text" className="form-control" id="lastname" />
            </div>
            <div className="col">
              <label htmlFor="dob" className="form-label">
                DOB
              </label>
              <input type="date" className="form-control" id="dob" />
            </div>
          </div>
          <div className="row mb-3">
            <div className="col">
              <label htmlFor="email" className="form-label">
                Email address
              </label>
              <input
                type="email"
                className="form-control"
                id="email"
                aria-describedby="emailHelp"
                disabled
              />
              <div id="emailHelp" className="form-text">
                We'll never share your email with anyone else.
              </div>
            </div>
          </div>
          <div className="row mb-3">
            <div className="col">
              <label htmlFor="street" className="form-label">
                Street
              </label>
              <input type="text" className="form-control" id="street" />
            </div>
            <div className="col">
              <label htmlFor="city" className="form-label">
                City
              </label>
              <input type="text" className="form-control" id="city" />
            </div>
            <div className="col">
              <label htmlFor="state" className="form-label">
                State
              </label>
              <input type="text" className="form-control" id="state" />
            </div>
          </div>
          <div className="row mb-3">
            <div className="col">
              <label htmlFor="country" className="form-label">
                Country
              </label>
              <input type="text" className="form-control" id="country" />
            </div>
            <div className="col">
              <label htmlFor="zipcode" className="form-label">
                Zipcode
              </label>
              <input type="text" className="form-control" id="zipcode" />
            </div>
            <div className="col">
              <label htmlFor="contact" className="form-label">
                Contact
              </label>
              <input type="text" className="form-control" id="contact" />
            </div>
          </div>
          <button type="submit" className="btn btn-primary">
            Update Profile
          </button>
        </form>
      </div>
    </div>
  );
}

export default UpdateProfile;
