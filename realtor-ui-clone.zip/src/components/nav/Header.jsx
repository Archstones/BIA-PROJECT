import { Fragment, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { APP_NAME } from "../../config/app.config";
import Footer from "./Footer";

function Header(props) {
  const [authToken] = useState(localStorage.getItem("realtor-token"));
  const [username] = useState(localStorage.getItem("realtor-username"));
  const navigate = useNavigate();
  return (
    <Fragment>
      <div
        className={`container-fluid w-100 ${!props.noFooter && "h-100"}`}
        style={{
          backgroundImage: `url(${"https://layjao.com/wp-content/uploads/2018/12/more-5-easy-modern-cream-living-room-ideas-cream-leather-sofa-which.jpg"})`,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
        }}
      >
        <div className="container d-flex mx-auto flex-column">
          <header className={`${!props.noFooter ? "mb-5 py-4" : "pt-4 pb-4"}`}>
            <div className="d-flex justify-content-between">
              <div className="d-flex">
                <img src="./logo192.png" alt="logo" width={32} height={32} />
                &nbsp;
                <h3 className="float-md-start mb-0">{APP_NAME}</h3>
              </div>
              <nav className="nav justify-content-center float-md-end">
                {!authToken ? (
                  <Fragment>
                    <Link to={"/login"} className="nav-link text-dark">
                      Login
                    </Link>
                    <Link to={"/signup"} className="nav-link text-dark">
                      Signup
                    </Link>
                  </Fragment>
                ) : (
                  <Fragment>
                    <Link to={"/settings"} className="nav-link text-dark">
                      <i className="bi-person-fill"></i> {username}
                    </Link>
                    <Link
                      to={"/logout"}
                      className="nav-link text-dark"
                      onClick={(ev) => {
                        ev.preventDefault();
                        localStorage.removeItem("realtor-username");
                        localStorage.removeItem("realtor-email");
                        localStorage.removeItem("realtor-token");
                        localStorage.removeItem("realtor-isauthenticated");
                        navigate("/login", { replace: true });
                      }}
                    >
                      Logout <i className="bi-box-arrow-right"></i>
                    </Link>
                  </Fragment>
                )}
              </nav>
            </div>
          </header>

          {props.children}
        </div>
      </div>
      <Footer />
    </Fragment>
  );
}

export default Header;
