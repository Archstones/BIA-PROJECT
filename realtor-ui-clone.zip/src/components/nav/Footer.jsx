import { APP_NAME } from "../../config/app.config";

function Footer() {
  return (
    <footer className="mt-auto bg-dark text-white p-3 position-sticky">
      <span>&copy; {APP_NAME} 2022</span>
    </footer>
  );
}

export default Footer;
