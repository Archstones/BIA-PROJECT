import { Navigate, Route, Routes } from "react-router-dom";
import Login from "./components/auth/login/Login";
import Signup from "./components/auth/signup/Signup";
import Home from "./components/Home";
import Profile from "./components/profile/Profile";
import AddProperty from "./components/property/AddProperty";
import AllProperty from "./components/property/AllProperty";
import Favorites from "./components/property/Favorites";
import MyProperty from "./components/property/MyProperty";
import PropertyDetail from "./components/property/PropertyDetail";
import SavedSearch from "./components/search/SavedSearch";
import SearchResult from "./components/search/SearchResult";
import Settings from "./components/settings/Settings";

import NotFound from "./hoc/NotFound";
import ProtectedRoute from "./hoc/ProtectedRoute";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to={"home"} replace />}></Route>
      <Route path="/home" element={<Home />}></Route>
      <Route path="/login" element={<Login />}></Route>
      <Route path="/signup" element={<Signup />}></Route>

      <Route
        path="settings"
        element={
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        }
      >
        <Route
          path=""
          element={<Navigate to={"update-profile"} replace />}
        ></Route>
        <Route path="add-listing" element={<AddProperty />}></Route>
        <Route path="update-profile" element={<Profile />}></Route>
        <Route path="favorites" element={<Favorites />}></Route>
        <Route path="properties" element={<MyProperty />}></Route>
        <Route path="all-properties" element={<AllProperty />}></Route>
        <Route path="saved-search" element={<SavedSearch />}></Route>
      </Route>
      <Route path="/property/:propertyId" element={<PropertyDetail />}></Route>
      <Route path="/search/results" element={<SearchResult />}></Route>
      <Route path="*" element={<NotFound />}></Route>
    </Routes>
  );
}

export default App;
