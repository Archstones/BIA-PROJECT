const mongoose = require("mongoose");

var mongoDB = "mongodb://localhost:27017/realrental";
module.exports = mongoose.connect(mongoDB);
