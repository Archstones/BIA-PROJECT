const mongoose = require("mongoose");
const {
  userSchema,
  propertySchema,
  propertyImageSchema,
  favoritePropertySchema,
  searchSchema,
} = require("./schema");

const User = mongoose.model("User", userSchema);

const Property = mongoose.model("Property", propertySchema);

const PropertyImage = mongoose.model("PropertyImages", propertyImageSchema);

const FavoriteProperty = mongoose.model(
  "FavoriteProperty",
  favoritePropertySchema
);

const Search = mongoose.model("Search", searchSchema);

module.exports = {
  User,
  Property,
  PropertyImage,
  FavoriteProperty,
  Search,
};
