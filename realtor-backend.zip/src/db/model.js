const mongoose = require("mongoose");
const { userSchema, propertySchema, propertyImageSchema } = require("./schema");

const User = mongoose.model("User", userSchema);

const Property = mongoose.model("Property", propertySchema);

const PropertyImage = mongoose.model("PropertyImages", propertyImageSchema);

module.exports = {
  User,
  Property,
  PropertyImage,
};
