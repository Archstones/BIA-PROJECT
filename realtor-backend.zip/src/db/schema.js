const mongoose = require("mongoose");
const { Schema } = mongoose;

const userSchema = new Schema({
  _id: String,
  email: { type: String, required: true },
  fname: { type: String, required: true },
  lname: { type: String, required: true },
  street: String,
  city: String,
  state: String,
  country: String,
  postalCode: String,
  phoneNumber: String,
  dob: { type: Date },
  password: String,
});

const propertySchema = new Schema({
  name: String,
  description: String,
  amenties: String,
  condition: String,
  type: String,
  transaction: String,
  dimension: {
    length: Number,
    height: Number,
    width: Number,
  },
  address: {
    street: String,
    city: String,
    state: String,
    country: String,
    zipcode: String,
    latitude: Number,
    longitude: Number,
  },
  price: Number,
  sqftPrice: Number,
  features: {
    beds: Number,
    baths: Number,
    landsize: Number,
    storeys: Number,
    other: { type: [String] },
  },
  owner: String,
  images: { type: [String] },
});

const propertyImageSchema = new Schema({
  imagePath: String,
});

module.exports = {
  userSchema,
  propertySchema,
  propertyImageSchema,
};
