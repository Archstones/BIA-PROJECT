const express = require("express");
const { Property, Search } = require("../db/model");
const router = express.Router();
const appLogger = require("../logger/appLogger");
const verifyToken = require("../middleware/auth");

router.use(appLogger);

router.get("/property/:searchWord", verifyToken, async (req, res) => {
  try {
    const email = req.user;
    const searchBy = req.params["searchWord"];
    const properties = await Property.find({
      $text: { $search: searchBy },
    }).lean();
    await new Search({
      savedOn: new Date(),
      searchBy,
      user: email,
    }).save();
    res.send(properties);
  } catch (err) {
    console.log(err);
  }
});

router.get("/saved", verifyToken, async (req, res) => {
  try {
    const email = req.user;
    const savedSearches = await Search.find({ user: email }).lean();
    res.send(savedSearches);
  } catch (err) {
    console.log(err);
  }
});

module.exports = router;
