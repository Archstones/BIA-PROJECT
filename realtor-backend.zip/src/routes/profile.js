const bcrypt = require("bcryptjs");
const express = require("express");
const { User } = require("../db/model");
const router = express.Router();
const appLogger = require("../logger/appLogger");
const verifyToken = require("../middleware/auth");

router.use(appLogger);

router.get("/", verifyToken, async (req, res) => {
  try {
    const email = req.user;
    const user = await User.findOne({ email }).lean();
    if (user) {
      delete user.password;
      delete user.__v;
      delete user._id;
      res.status(200).json({ ...user });
    } else {
      res.status(409).send({ message: "User not found" });
    }
  } catch (err) {
    console.log(err);
  }
});

router.post("/update", verifyToken, async (req, res) => {
  try {
    const { street, city, state, country, postalCode, phoneNumber, dob } = req.body;
    const email = req.user;
    const user = await User.findOne({ email });
    if (user) {
      const resp = await User.findOneAndUpdate(
        { email },
        {
          street: street || user.street || "",
          city: city || user.city || "",
          state: state || user.state || "",
          country: country || user.country || "",
          postalCode: postalCode || user.postalCode || "",
          phoneNumber: phoneNumber || user.phoneNumber || "",
          // dob: dob ? new Date(Date.parse(dob)) : "",
        }
      );
      if (resp) {
        res.status(200).json({ message: "Profile updated successfully" });
      }
    } else {
      res.status(409).send({ message: "User not found" });
    }
  } catch (err) {
    console.log(err);
  }
});

router.post("/update-password", verifyToken, async (req, res) => {
  try {
    const { oldPassword, newPassword, confirmPassword } = req.body;
    if (!(oldPassword && newPassword && confirmPassword)) {
      if (newPassword !== confirmPassword) {
        res.status(400).send({ message: "Password mismatch" });
      }
      res.status(400).send({ message: "All input is required" });
    }
    const email = req.user;
    const user = await User.findOne({ email });
    if (user && (await bcrypt.compare(oldPassword, user.password))) {
      const encryptedPassword = await bcrypt.hash(confirmPassword, 10);
      const resp = await User.findOneAndUpdate(
        { email },
        { password: encryptedPassword }
      );
      if (resp) {
        res.status(200).json({ message: "Password updated successfully" });
      }
    } else {
      res.status(409).send({ message: "User not found" });
    }
  } catch (err) {
    console.log(err);
  }
});

module.exports = router;
