const express = require("express");
const fs = require("fs");
const router = express.Router();
const appLogger = require("../logger/appLogger");
const verifyToken = require("../middleware/auth");

const multer = require("multer");
const {
  Property,
  User,
  PropertyImage,
  FavoriteProperty,
} = require("../db/model");
const path = require("path");
const { default: mongoose } = require("mongoose");
const upload = multer({ dest: "assets/upload" });

router.use(appLogger);

router.post(
  "/add-new",
  verifyToken,
  upload.array("property", 5),
  async (req, res) => {
    try {
      const reqBody = JSON.parse(req.body["data"]);
      const reqFiles = req.files;
      const email = req.user;
      const images = [];
      reqFiles.forEach(async (file) => {
        var fileName = file.originalname;
        var extension = fileName.substr(fileName.indexOf(".") + 1);
        var filePath = file.path + "." + extension;
        fs.renameSync(file.path, filePath);
        const propertyImage = new PropertyImage({
          imagePath: filePath,
        });
        const imageResp = await propertyImage.save();
        images.push(imageResp._id.toString());
      });
      const user = await User.findOne({ email });
      if (user) {
        const property = new Property({ ...reqBody, owner: user, images });
        const resp = await property.save();
        if (resp) {
          res.status(200).json({ message: "Property added successfully" });
        }
      } else {
        res.status(409).send({ message: "User not found" });
      }
    } catch (err) {
      console.log(err);
    }
  }
);

router.get("/image", verifyToken, async (req, res) => {
  try {
    const imageId = req.query["id"];
    const image = await PropertyImage.findOne({
      _id: mongoose.Types.ObjectId(imageId),
    });
    const filePath = image["imagePath"];
    const fileExtension = filePath
      .substring(filePath.lastIndexOf(".") + 1)
      .toUpperCase();
    res.setHeader(
      "Content-Type",
      fileExtension === "JPG" || fileExtension === "JPEG"
        ? "image/jpeg"
        : fileExtension === "PNG"
        ? "image/png"
        : fileExtension === "GIF"
        ? "image/gif"
        : "image/bmp"
    );
    res.setHeader("Cache-Control", "max-age=604800");
    res.send(fs.readFileSync(path.join(__dirname, "..\\..\\", filePath)));
  } catch (err) {
    console.log(err);
  }
});

router.get("/my", verifyToken, async (req, res) => {
  try {
    const email = req.user;
    let properties = await Property.find({ owner: email });
    properties = properties.map((property) => {
      let images = property.images.map((image) =>
        mongoose.Types.ObjectId(image)
      );
      property["images"] = images;
      return property;
    });
    res.status(200).send(properties);
  } catch (err) {
    console.log(err);
  }
});

router.get("/", verifyToken, async (req, res) => {
  try {
    let properties = await Property.find();
    properties = properties.map((property) => {
      let images = property.images.map((image) =>
        mongoose.Types.ObjectId(image)
      );
      property["images"] = images;
      return property;
    });
    res.status(200).send(properties);
  } catch (err) {
    console.log(err);
  }
});

router.get("/:propertyId/details", verifyToken, async (req, res) => {
  try {
    let email = req.user;
    let property = await Property.findOne({
      _id: mongoose.Types.ObjectId(req.params["propertyId"]),
    });
    let images = property.images.map((image) => mongoose.Types.ObjectId(image));
    let favorite = await FavoriteProperty.findOne({ _id: email });
    let isFavorite = favorite?.property
      ?.map((p) => p.toString())
      ?.indexOf(req.params["propertyId"]);
    property["images"] = images;
    res.status(200).send({ ...property._doc, favorite: isFavorite !== -1 });
  } catch (err) {
    console.log(err);
  }
});

router.post("/favorite", verifyToken, async (req, res) => {
  try {
    const propertyId = req.body["property"];
    const email = req.user;
    const favProperty = await FavoriteProperty.findOne({ _id: email });
    let isAdded = false;
    if (favProperty) {
      let favProperties = favProperty["property"].map((p) => p.toString());
      const index = favProperties.indexOf(propertyId);
      if (index > -1) {
        favProperties.splice(index, 1);
      } else {
        favProperties.push(propertyId);
        isAdded = true;
      }
      favProperty.property = favProperties;
      await favProperty.save();
    } else {
      const favorite = new FavoriteProperty({
        _id: email,
        property: [propertyId],
      });
      await favorite.save();
      isAdded = true;
    }
    res.status(200).send({ status: isAdded });
  } catch (err) {
    console.log(err);
  }
});

router.get("/favorite", verifyToken, async (req, res) => {
  try {
    const email = req.user;
    const favProperty = await FavoriteProperty.findOne({ _id: email });
    let properties = await Property.find({
      _id: { $in: [...favProperty.property] },
    });
    properties = properties.map((property) => {
      let images = property.images.map((image) =>
        mongoose.Types.ObjectId(image)
      );
      property["images"] = images;
      return property;
    });
    res.status(200).send(properties);
  } catch (err) {
    console.log(err);
  }
});

module.exports = router;
