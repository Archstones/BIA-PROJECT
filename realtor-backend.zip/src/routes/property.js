const express = require("express");
const fs = require("fs");
const router = express.Router();
const appLogger = require("../logger/appLogger");
const verifyToken = require("../middleware/auth");

const multer = require("multer");
const { Property, User, PropertyImage } = require("../db/model");
const upload = multer({ dest: "assets/upload" });

router.use(appLogger);

router.post(
  "/add-new",
  verifyToken,
  upload.array("property", 5),
  async (req, res) => {
    try {
      const reqBody = JSON.parse(req.body["data"]);
      const reqFiles = req.files;
      const email = req.user;
      const images = [];
      reqFiles.forEach(async (file) => {
        var fileName = file.originalname;
        var extension = fileName.substr(fileName.indexOf(".") + 1);
        var filePath = file.path + "." + extension;
        fs.renameSync(file.path, filePath);
        const propertyImage = new PropertyImage({
          imagePath: filePath,
        });
        const imageResp = await propertyImage.save();
        images.push(imageResp._id.toString());
      });
      const user = await User.findOne({ email });
      if (user) {
        const property = new Property({ ...reqBody, owner: user, images });
        const resp = await property.save();
        if (resp) {
          res.status(200).json({ message: "Property added successfully" });
        }
      } else {
        res.status(409).send({ message: "User not found" });
      }
    } catch (err) {
      console.log(err);
    }
  }
);

module.exports = router;
