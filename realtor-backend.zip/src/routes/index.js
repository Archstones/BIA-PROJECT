const authRoute = require("./auth");
const propertyRoute = require("./property");
const profileRoute = require("./profile");
const searchRoute = require("./search");

module.exports = { authRoute, propertyRoute, profileRoute, searchRoute };
