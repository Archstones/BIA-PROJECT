const authRoute = require("./auth");
const propertyRoute = require("./property");
const profileRoute = require("./profile");

module.exports = { authRoute, propertyRoute, profileRoute };
