const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { User } = require("../db/model");
const router = express.Router();
const appLogger = require("../logger/appLogger");

router.use(appLogger);

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!(email && password)) {
      res.status(400).send({ message: "All input is required" });
    }
    const user = await User.findOne({ email });
    if (user && (await bcrypt.compare(password, user.password))) {
      const token = jwt.sign({ email }, process.env.TOKEN_KEY, {
        expiresIn: "2h",
      });
      res
        .status(200)
        .json({
          email,
          message: "User authenticated successfully",
          name: user.fname + " " + user.lname,
          token,
        });
    }
    res.status(400).send({ message: "Invalid Credentials" });
  } catch (err) {
    console.log(err);
  }
});

router.post("/signup", async (req, res) => {
  const { username, email, password } = req.body;
  const name = username.split(" ");
  const firstname = name[0];
  const lastname = name.length > 1 ? name[1] : "";
  const oldUser = await User.findOne({ email });
  if (oldUser) {
    res.status(409).send({ message: "User Already Exist. Please Login" });
  } else {
    const encryptedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      _id: email,
      email,
      fname: firstname,
      lname: lastname,
      password: encryptedPassword,
    });
    const resp = await user.save();
    if (resp) {
      res.send({
        status: 200,
        email: email,
        message: "User created successfully",
      });
    } else {
      res.status(500).send({ message: "Unable to save the user" });
    }
  }
});

module.exports = router;
