const express = require("express");
const dbConnection = require("./src/db/connection");
const cors = require("cors");
const app = express();
const {
  authRoute,
  propertyRoute,
  profileRoute,
  searchRoute,
} = require("./src/routes");
const port = 8000;

require("dotenv").config();

app.use(express.json());
app.use(cors());

dbConnection
  .then(() => {
    app.listen(port, () => {
      app.use("/api/auth", authRoute);
      app.use("/api/property", propertyRoute);
      app.use("/api/profile", profileRoute);
      app.use("/api/search", searchRoute);
      console.log(`App listening on the port ${port}`);
    });
  })
  .catch((err) => console.log(`Mongodb connection error: ${err}`));
